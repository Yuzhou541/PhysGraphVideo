# PhysGraphVideoCVPR
(see run commands in the chat message)
